package com.yoann.calcul;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculsTest {

	@BeforeEach
	public void initTest()
	{
		Calculs c = new Calculs(5,10);
	}
	
	
	@Test
	public void test() 
	{
		
		
	}

}
